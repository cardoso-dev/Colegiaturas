/*
 * RprtEntIngreso.java
 * Parte de proyecto: Colegiaturas
 * Author: Pedro Cardoso Rodriguez
 * Mail: cardp_2004@yahoo.com.mx
 * Place: Zacatecas Mexico
 * 
    Copyright © 2013 Pedro Cardoso Rodriguez

    COLEGIATURAS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any 
    later version.

    COLEGIATURAS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with COLEGIATURAS.  If not, see <http://www.gnu.org/licenses/>
 */
package colegiaturas.others;

/**
 *
 * @author Pedro
 */
public class RprtEntIngreso {
    private String fecha;
    private String alumno;
    private String concepto;
    private String monto;

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setAlumno(String alumno) {
        this.alumno = alumno;
    }

    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }

    public void setMonto(String monto) {
        this.monto = monto;
    }

    public String getFecha() {
        return fecha;
    }

    public String getAlumno() {
        return alumno;
    }

    public String getConcepto() {
        return concepto;
    }

    public String getMonto() {
        return monto;
    }

    public RprtEntIngreso() {
    }

    public RprtEntIngreso(String fecha, String alumno, String concepto, String monto) {
        this.fecha = fecha;
        this.alumno = alumno;
        this.concepto = concepto;
        this.monto = monto;
    }
}

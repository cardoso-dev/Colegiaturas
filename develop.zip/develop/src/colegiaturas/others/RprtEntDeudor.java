/*
 * RprtEntDeudor.java
 * Parte de proyecto: Colegiaturas
 * Author: Pedro Cardoso Rodriguez
 * Mail: cardp_2004@yahoo.com.mx
 * Place: Zacatecas Mexico
 * 
    Copyright © 2013 Pedro Cardoso Rodriguez

    COLEGIATURAS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any 
    later version.

    COLEGIATURAS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with COLEGIATURAS.  If not, see <http://www.gnu.org/licenses/>
 */
package colegiaturas.others;

/**
 *
 * @author Pedro
 */
public class RprtEntDeudor {
    private String alumno;
    private String grupo;
    private String conscep;

    public String getAlumno() {
        return alumno;
    }
    
    public String getGrupo() {
        return grupo;
    }

    public String getConscep() {
        return conscep;
    }

    public void setAlumno(String alumno) {
        this.alumno = alumno;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public void setConscep(String conscep) {
        this.conscep = conscep;
    }

    public RprtEntDeudor() {
    }

    public RprtEntDeudor(String alumno, String grupo, String conscep){
        this.alumno = alumno;
        this.grupo = grupo;
        this.conscep=conscep;
    }
}

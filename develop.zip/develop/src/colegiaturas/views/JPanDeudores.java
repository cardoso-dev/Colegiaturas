/*
 * JPanDeudores.java
 * Parte de proyecto: Colegiaturas
 * Author: Pedro Cardoso Rodriguez
 * Mail: cardp_2004@yahoo.com.mx
 * Place: Zacatecas Mexico
 * 
    Copyright © 2013 Pedro Cardoso Rodriguez

    COLEGIATURAS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any 
    later version.

    COLEGIATURAS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with COLEGIATURAS.  If not, see <http://www.gnu.org/licenses/>
 */
package colegiaturas.views;

import colegiaturas.entities.Alumno;
import colegiaturas.entities.Ciclo;
import colegiaturas.entities.Grupo;
import colegiaturas.entities.Pago;
import colegiaturas.others.RprtEntDeudor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.TypedQuery;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Pedro
 */
public class JPanDeudores extends JPanList {

    private List<Pago> lista;
    private List<Grupo> grupos;
    private int page;
    private Ciclo cl;
    
    /**
     * Creates new form JPanDeudores
     */
    public JPanDeudores(MainView mv) {
        super(mv);
        initComponents();
        loadCiclos();
        page=0;
    }

    private void loadCiclos(){
        List<Ciclo> ciclos=MainView.em.createNamedQuery("Ciclo.findAll",Ciclo.class).getResultList();
        jcbCiclos.removeAllItems();
        for(Ciclo row: ciclos){
            jcbCiclos.addItem(row);
        }
    }
    
    private void reload(){
        int num=(page*MainView.maxPag);
        long total;
        Object[] rowArray;
        Alumno al;
        Grupo gpr;
        String cjpql="SELECT COUNT(p) FROM Pago p WHERE";
        TypedQuery query;
        TypedQuery cquery;
        loadGruposByCiclo();
        cjpql=addGruposClausule(cjpql);
        cjpql=addConceptoClausule(cjpql);
        query=buildQuery(true, num);
        cquery=MainView.em.createQuery(cjpql,Long.class);
        cquery=addGruposParams(cquery);        
        lista=query.getResultList();
        total=Long.parseLong(cquery.getSingleResult().toString());
        DefaultTableModel tmodel=(DefaultTableModel)jxTabla.getModel();
        for(int itr=tmodel.getRowCount();itr>0;itr--){
            tmodel.removeRow(itr-1);
        }
        for(Pago row: lista){
            al=row.getAlumno();
            gpr=row.getGrupo();
            rowArray=new Object[6];
            rowArray[0]=++num;
            rowArray[1]=al.getApp()+" "+al.getApm()+" "+al.getNombre();
            rowArray[2]=gpr.getGrado()+" "+gpr.getGrupo();
            rowArray[3]=row.getConcepto();
            tmodel.addRow(rowArray);
        }
        btnImp.setEnabled(lista.size()>0);
        btnPrv.setEnabled(page>0);
        btnNxt.setEnabled(((page+1)*MainView.maxPag)<total);
        jxTabla.setModel(tmodel);
        lblPag.setText("Pag "+(page+1)+" de "+(int)Math.ceil((double)total/(double)MainView.maxPag));
    }
    
    private TypedQuery buildQuery(boolean limit, int ini){
        String jpql="SELECT p FROM Pago p WHERE ";
        TypedQuery query;
        jpql=addGruposClausule(jpql);
        jpql=addConceptoClausule(jpql);
        query=MainView.em.createQuery(jpql,Pago.class);
        if(limit){
            query.setMaxResults(MainView.maxPag);
        }
        query.setFirstResult(ini);
        query=addGruposParams(query);
        return query;
    }
    
    private List loadGruposByCiclo(){
        cl=((Ciclo)jcbCiclos.getSelectedItem());
        TypedQuery query=MainView.em.createNamedQuery("Grupo.findByCiclo",Grupo.class);
        query.setParameter("ciclo",cl);
        grupos=query.getResultList();
        return grupos;
    }
    
    private String addGruposClausule(String jpql){
        int h;
        String clausule="";
        for(h=0;h<grupos.size();h++){
            clausule+=(h>0?" or ":"")+" p.grupo=:gpr"+h;
        }
        return jpql+(clausule.equals("")?" p.grupo.idg=-1":"("+clausule+")");
    }
    
    private String addConceptoClausule(String jpql){
        String clausule1="";
        String clausule0="";
        if(jckInsc.isSelected()){ clausule1+="(p.clvpago=0 and p.pagado<2)"; }
        else{ clausule0+="(p.clvpago<>0)";}
        if(jckEne.isSelected()){ clausule1+=(clausule1.length()==0?"":" or ")+"(p.clvpago=1 and p.pagado<2)"; }
        else{ clausule0+=(clausule0.length()==0?"":" and ")+"(p.clvpago<>1)"; }
        if(jckFeb.isSelected()){ clausule1+=(clausule1.length()==0?"":" or ")+"(p.clvpago=2 and p.pagado<2)"; }
        else{ clausule0+=(clausule0.length()==0?"":" and ")+"(p.clvpago<>2)";}
        if(jckMar.isSelected()){ clausule1+=(clausule1.length()==0?"":" or ")+"(p.clvpago=3 and p.pagado<2)"; }
        else{ clausule0+=(clausule0.length()==0?"":" and ")+"(p.clvpago<>3)"; }
        if(jckAbr.isSelected()){ clausule1+=(clausule1.length()==0?"":" or ")+"(p.clvpago=4 and p.pagado<2)"; }
        else{ clausule0+=(clausule0.length()==0?"":" and ")+"(p.clvpago<>4)"; }
        if(jckMay.isSelected()){ clausule1+=(clausule1.length()==0?"":" or ")+"(p.clvpago=5 and p.pagado<2)"; }
        else{ clausule0+=(clausule0.length()==0?"":" and ")+"(p.clvpago<>5)"; }
        if(jckJun.isSelected()){ clausule1+=(clausule1.length()==0?"":" or ")+"(p.clvpago=6 and p.pagado<2)"; }
        else{ clausule0+=(clausule0.length()==0?"":" and ")+"(p.clvpago<>6)"; }
        if(jckJul.isSelected()){ clausule1+=(clausule1.length()==0?"":" or ")+"(p.clvpago=7 and p.pagado<2)"; }
        else{ clausule0+=(clausule0.length()==0?"":" and ")+"(p.clvpago<>7)"; }
        if(jckAgo.isSelected()){ clausule1+=(clausule1.length()==0?"":" or ")+"(p.clvpago=8 and p.pagado<2)"; }
        else{ clausule0+=(clausule0.length()==0?"":" and ")+"(p.clvpago<>8)"; }
        if(jckSep.isSelected()){ clausule1+=(clausule1.length()==0?"":" or ")+"(p.clvpago=9 and p.pagado<2)"; }
        else{ clausule0+=(clausule0.length()==0?"":" and ")+"(p.clvpago<>9)"; }
        if(jckOct.isSelected()){ clausule1+=(clausule1.length()==0?"":" or ")+"(p.clvpago=10 and p.pagado<2)"; }
        else{ clausule0+=(clausule0.length()==0?"":" and ")+"(p.clvpago<>10)"; }
        if(jckNov.isSelected()){ clausule1+=(clausule1.length()==0?"":" or ")+"(p.clvpago=11 and p.pagado<2)"; }
        else{ clausule0+=(clausule0.length()==0?"":" and ")+"(p.clvpago<>11)"; }
        if(jckDic.isSelected()){ clausule1+=(clausule1.length()==0?"":" or ")+"(p.clvpago=12 and p.pagado<2)"; }
        else{ clausule0+=(clausule0.length()==0?"":" and ")+"(p.clvpago<>12)"; }
        return jpql+(clausule1.length()==0?"":" and ("+clausule1+")")+(clausule0.length()==0?"":" and ("+clausule0+")");
    }
    
    private TypedQuery addGruposParams(TypedQuery qry){
        int h;
        for(h=0;h<grupos.size();h++){
            qry.setParameter("gpr"+h,grupos.get(h));
        }
        return qry;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jcbCiclos = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jckDic = new javax.swing.JCheckBox();
        jckNov = new javax.swing.JCheckBox();
        jckOct = new javax.swing.JCheckBox();
        jckSep = new javax.swing.JCheckBox();
        jckAgo = new javax.swing.JCheckBox();
        jckJul = new javax.swing.JCheckBox();
        jckJun = new javax.swing.JCheckBox();
        jckMay = new javax.swing.JCheckBox();
        jckAbr = new javax.swing.JCheckBox();
        jckEne = new javax.swing.JCheckBox();
        jckFeb = new javax.swing.JCheckBox();
        jckInsc = new javax.swing.JCheckBox();
        jckMar = new javax.swing.JCheckBox();
        btnTodos = new javax.swing.JButton();
        btnInvert = new javax.swing.JButton();
        btnBusca = new javax.swing.JButton();
        btnNxt = new javax.swing.JButton();
        btnPrv = new javax.swing.JButton();
        btnImp = new javax.swing.JButton();
        lblPag = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jxTabla = new org.jdesktop.swingx.JXTable();

        setLayout(new java.awt.BorderLayout());

        jLabel1.setText("Filtrar por:");

        jLabel2.setText("Ciclo:");

        jLabel3.setText("Concepto:");

        jckDic.setText("Diciembre");

        jckNov.setText("Noviembre");

        jckOct.setText("Octubre");

        jckSep.setText("Septiembre");

        jckAgo.setText("Agosto");

        jckJul.setText("Julio");

        jckJun.setText("Junio");

        jckMay.setText("Mayo");

        jckAbr.setText("Abril");

        jckEne.setText("Enero");

        jckFeb.setText("Febrero");

        jckInsc.setText("Inscripcion");

        jckMar.setText("Marzo");

        btnTodos.setText("*");
        btnTodos.setToolTipText("Selecionar todos");
        btnTodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTodosActionPerformed(evt);
            }
        });

        btnInvert.setText("!");
        btnInvert.setToolTipText("Invertir seleccion");
        btnInvert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInvertActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jckEne)
                            .addComponent(jckMar)
                            .addComponent(jckMay)
                            .addComponent(jckSep)
                            .addComponent(jckJul)
                            .addComponent(jckNov))
                        .addGap(4, 4, 4)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jckDic)
                            .addComponent(jckOct)
                            .addComponent(jckAgo)
                            .addComponent(jckJun)
                            .addComponent(jckAbr)
                            .addComponent(jckFeb)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jckInsc))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnTodos)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnInvert)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jckInsc)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jckEne)
                    .addComponent(jckFeb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jckMar)
                    .addComponent(jckAbr))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jckMay)
                    .addComponent(jckJun))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jckJul)
                    .addComponent(jckAgo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jckSep)
                    .addComponent(jckOct))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jckNov)
                    .addComponent(jckDic))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTodos)
                    .addComponent(btnInvert))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnBusca.setText("Buscar");
        btnBusca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscaActionPerformed(evt);
            }
        });

        btnNxt.setText(">");
        btnNxt.setEnabled(false);
        btnNxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNxtActionPerformed(evt);
            }
        });

        btnPrv.setText("<");
        btnPrv.setEnabled(false);
        btnPrv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrvActionPerformed(evt);
            }
        });

        btnImp.setText("Imprimir");
        btnImp.setToolTipText("Imprimir listado actual");
        btnImp.setEnabled(false);
        btnImp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImpActionPerformed(evt);
            }
        });

        lblPag.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPag.setText("Pag X de X");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jcbCiclos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnBusca, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(btnImp)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(lblPag, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(btnPrv)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnNxt)))))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jcbCiclos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBusca)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(lblPag)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNxt)
                    .addComponent(btnPrv)
                    .addComponent(btnImp))
                .addContainerGap())
        );

        add(jPanel1, java.awt.BorderLayout.LINE_END);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Busqueda de deudores");
        add(jLabel4, java.awt.BorderLayout.PAGE_START);

        jxTabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "Alumno", "Grupo", "Concepto"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jxTabla);
        jxTabla.getColumnModel().getColumn(0).setPreferredWidth(35);
        jxTabla.getColumnModel().getColumn(1).setPreferredWidth(120);
        jxTabla.getColumnModel().getColumn(2).setPreferredWidth(129);
        jxTabla.getColumnModel().getColumn(3).setPreferredWidth(110);

        add(jScrollPane2, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscaActionPerformed
        reload();
    }//GEN-LAST:event_btnBuscaActionPerformed

    private void btnNxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNxtActionPerformed
        page+=1;
        reload();
    }//GEN-LAST:event_btnNxtActionPerformed

    private void btnPrvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrvActionPerformed
        page-=1;
        reload();
    }//GEN-LAST:event_btnPrvActionPerformed

    private void btnTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTodosActionPerformed
        jckInsc.setSelected(true);
        jckEne.setSelected(true);
        jckFeb.setSelected(true);
        jckMar.setSelected(true);
        jckAbr.setSelected(true);
        jckMay.setSelected(true);
        jckJun.setSelected(true);
        jckJul.setSelected(true);
        jckAgo.setSelected(true);
        jckSep.setSelected(true);
        jckOct.setSelected(true);
        jckNov.setSelected(true);
        jckDic.setSelected(true);
    }//GEN-LAST:event_btnTodosActionPerformed

    private void btnInvertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInvertActionPerformed
        jckInsc.setSelected(!jckInsc.isSelected());
        jckEne.setSelected(!jckEne.isSelected());
        jckFeb.setSelected(!jckFeb.isSelected());
        jckMar.setSelected(!jckMar.isSelected());
        jckAbr.setSelected(!jckAbr.isSelected());
        jckMay.setSelected(!jckMay.isSelected());
        jckJun.setSelected(!jckJun.isSelected());
        jckJul.setSelected(!jckJul.isSelected());
        jckAgo.setSelected(!jckAgo.isSelected());
        jckSep.setSelected(!jckSep.isSelected());
        jckOct.setSelected(!jckOct.isSelected());
        jckNov.setSelected(!jckNov.isSelected());
        jckDic.setSelected(!jckDic.isSelected());
    }//GEN-LAST:event_btnInvertActionPerformed

    private void btnImpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImpActionPerformed
        JDImprime jdim=new JDImprime(mv,true);
        jdim.setLocationRelativeTo(mv);
        jdim.cargaReporte(getParams(), getListCampos(),1);
        jdim.setVisible(true);
    }//GEN-LAST:event_btnImpActionPerformed

    private Map<String,Object> getParams(){
        Map<String,Object> parametros = new HashMap<String,Object>();
        parametros.put("institute_name",mv.getInstiName());
        parametros.put("ciclo",cl.toString());
        return parametros;
    }
    
    private ArrayList getListCampos(){
        ArrayList listCampos=new ArrayList();
        List<Pago> wLista;
        RprtEntDeudor campo;
        TypedQuery query;
        Alumno alu;
        Grupo gpo;
        loadGruposByCiclo();
        query=buildQuery(false, 0);
        wLista=query.getResultList();
        for(Pago row: wLista){
            alu=row.getAlumno();
            gpo=row.getGrupo();
            campo=new RprtEntDeudor(alu.getApp()+" "+alu.getApm()+" "+alu.getNombre(),
                    gpo.getGrado()+" "+gpo.getGrupo(),row.getConcepto());
            listCampos.add(campo);
        }
        return listCampos;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBusca;
    private javax.swing.JButton btnImp;
    private javax.swing.JButton btnInvert;
    private javax.swing.JButton btnNxt;
    private javax.swing.JButton btnPrv;
    private javax.swing.JButton btnTodos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JComboBox jcbCiclos;
    private javax.swing.JCheckBox jckAbr;
    private javax.swing.JCheckBox jckAgo;
    private javax.swing.JCheckBox jckDic;
    private javax.swing.JCheckBox jckEne;
    private javax.swing.JCheckBox jckFeb;
    private javax.swing.JCheckBox jckInsc;
    private javax.swing.JCheckBox jckJul;
    private javax.swing.JCheckBox jckJun;
    private javax.swing.JCheckBox jckMar;
    private javax.swing.JCheckBox jckMay;
    private javax.swing.JCheckBox jckNov;
    private javax.swing.JCheckBox jckOct;
    private javax.swing.JCheckBox jckSep;
    private org.jdesktop.swingx.JXTable jxTabla;
    private javax.swing.JLabel lblPag;
    // End of variables declaration//GEN-END:variables
}

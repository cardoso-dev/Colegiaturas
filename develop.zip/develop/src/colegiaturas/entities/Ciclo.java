/*
 * Ciclo.java
 *   Entidad ciclo
 * Parte de proyecto: Colegiaturas
 * Author: Pedro Cardoso Rodriguez
 * Mail: cardp_2004@yahoo.com.mx
 * Place: Zacatecas Mexico
 * 
    Copyright © 2013 Pedro Cardoso Rodriguez

    COLEGIATURAS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any 
    later version.

    COLEGIATURAS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with COLEGIATURAS.  If not, see <http://www.gnu.org/licenses/>
 */
package colegiaturas.entities;

import java.io.Serializable;
import java.text.DateFormat;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Pedro
 */
@Entity
@Table(name = "CICLO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ciclo.findAll", query = "SELECT c FROM Ciclo c ORDER BY c.ini DESC"),
    @NamedQuery(name = "Ciclo.countAll", query = "SELECT COUNT(c) FROM Ciclo c"),
    @NamedQuery(name = "Ciclo.findByIdc", query = "SELECT c FROM Ciclo c WHERE c.idc = :idc")})
public class Ciclo implements Serializable {
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "INSCRIPCION")
    private Double inscripcion;
    @Column(name = "MENSUALIDAD")
    private Double mensualidad;
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "IDC")
    private Integer idc;
    @Basic(optional = false)
    @Column(name = "INI")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date ini;
    @Basic(optional = false)
    @Column(name = "FIN")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date fin;

    public Ciclo() {
    }

    public Ciclo(int idc) {
        this.idc = idc;
    }

    public Ciclo(int idc, Date ini, Date fin, Double inscripcion, Double mensualidad) {
        this.idc = idc;
        this.ini = ini;
        this.fin = fin;
        this.inscripcion = inscripcion;
        this.mensualidad = mensualidad;
    }

    public Integer getIdc() {
        return idc;
    }

    public void setIdc(int idc) {
        this.idc = idc;
    }

    public void setIni(Date ini) {
        this.ini = ini;
    }

    public void setFin(Date fin) {
        this.fin = fin;
    }

    public Date getIni() {
        return ini;
    }

    public Date getFin() {
        return fin;
    }

    public String getFormatIni() {
        DateFormat df=DateFormat.getDateInstance();
        return df.format(ini);
    }

    public String getFormatFin() {
        DateFormat df=DateFormat.getDateInstance();
        return df.format(fin);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idc != null ? idc.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Ciclo)) {
            return false;
        }
        Ciclo other = (Ciclo) object;
        if ((this.idc == null && other.idc != null) || (this.idc != null && !this.idc.equals(other.idc))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return getFormatIni()+" : "+getFormatFin();
    }

    public Double getInscripcion() {
        return inscripcion;
    }

    public void setInscripcion(Double inscripcion) {
        this.inscripcion = inscripcion;
    }

    public Double getMensualidad() {
        return mensualidad;
    }

    public void setMensualidad(Double mensualidad) {
        this.mensualidad = mensualidad;
    }
    
}

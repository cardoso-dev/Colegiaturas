/*
 * Pago.java
 *   Entidad pago
 * Parte de proyecto: Colegiaturas
 * Author: Pedro Cardoso Rodriguez
 * Mail: cardp_2004@yahoo.com.mx
 * Place: Zacatecas Mexico
 * 
    Copyright © 2013 Pedro Cardoso Rodriguez

    COLEGIATURAS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any 
    later version.

    COLEGIATURAS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with COLEGIATURAS.  If not, see <http://www.gnu.org/licenses/>
 */
package colegiaturas.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Pedro
 */
@Entity
@Table(name = "PAGO")
@XmlRootElement
public class Pago implements Serializable {
    @Column(name = "CONCEPTO")
    private String concepto;
    @Column(name = "PAGADO")
    private int pagado;
    @Column(name = "CLVPAGO")
    private int clvpago;
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "IDP")
    private Long idp;
    @OneToOne
    private Alumno alumno;
    @OneToOne
    private Grupo grupo;
    @OneToMany(mappedBy="pago")
    private List<Ppago> ppago;

    public void setPpago(List<Ppago> ppago) {
        this.ppago = ppago;
    }

    public List<Ppago> getPpago() {
        return ppago;
    }

    public Pago() {
    }

    public Long getIdp() {
        return idp;
    }

    public void setClvpago(int clvpago) {
        this.clvpago = clvpago;
    }

    public int getClvpago() {
        return clvpago;
    }

    public void setId(Long idp) {
        this.idp = idp;
    }

    public void setInscrip(String concepto) {
        this.concepto = concepto;
    }

    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
    }

    public String getConcepto() {
        return concepto;
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public Grupo getGrupo() {
        return grupo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idp != null ? idp.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Pago)) {
            return false;
        }
        Pago other = (Pago) object;
        if ((this.idp == null && other.idp != null) || (this.idp != null && !this.idp.equals(other.idp))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ingresoscvg.entities.Pago[ id=" + idp + " ]";
    }

    public int getPagado() {
        return pagado;
    }

    public void setPagado(int pagado) {
        this.pagado = pagado;
    }
    
}

/*
 * Ppago.java
 *   Entidad Ppago
 * Parte de proyecto: Colegiaturas
 * Author: Pedro Cardoso Rodriguez
 * Mail: cardp_2004@yahoo.com.mx
 * Place: Zacatecas Mexico
 * 
    Copyright © 2013 Pedro Cardoso Rodriguez

    COLEGIATURAS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any 
    later version.

    COLEGIATURAS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with COLEGIATURAS.  If not, see <http://www.gnu.org/licenses/>
 */
package colegiaturas.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Pedro
 */
@Entity
public class Ppago implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "FACTURA")
    private String factura;
    @Column(name = "FECHA")
    @Temporal(TemporalType.DATE)
    private Date fecha;
    @Column(name = "MONTO")
    private double monto;
    @Column(name = "MEDIO")
    private String medio;
    @Column(name = "ABONO")
    private boolean abono;
    @ManyToOne
    @JoinColumn(name="PAGO_IDP")
    private Pago pago;

    public void setAbono(boolean abono) {
        this.abono = abono;
    }

    public boolean isAbono() {
        return abono;
    }

    public void setPago(Pago pago) {
        this.pago = pago;
    }

    public Pago getPago() {
        return pago;
    }

    public void setFactura(String factura) {
        this.factura = factura;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public void setMedio(String medio) {
        this.medio = medio;
    }

    public String getFactura() {
        return factura;
    }

    public Date getFecha() {
        return fecha;
    }

    public double getMonto() {
        return monto;
    }

    public String getMedio() {
        return medio;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ppago)) {
            return false;
        }
        Ppago other = (Ppago) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "colegiaturas.entities.Ppago[ id=" + id + " ]";
    }
    
}

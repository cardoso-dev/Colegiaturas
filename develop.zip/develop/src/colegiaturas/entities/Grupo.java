/*
 * Grupo.java
 *   Entidad Grupo
 * Parte de proyecto: Colegiaturas
 * Author: Pedro Cardoso Rodriguez
 * Mail: cardp_2004@yahoo.com.mx
 * Place: Zacatecas Mexico
 * 
    Copyright © 2013 Pedro Cardoso Rodriguez

    COLEGIATURAS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any 
    later version.

    COLEGIATURAS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with COLEGIATURAS.  If not, see <http://www.gnu.org/licenses/>
 */
package colegiaturas.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Pedro
 */
@Entity
@Table(name = "GRUPO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Grupo.findAll", query = "SELECT g FROM Grupo g"),
    @NamedQuery(name = "Grupo.findByIdg", query = "SELECT g FROM Grupo g WHERE g.idg = :idg"),
    @NamedQuery(name = "Grupo.findByCiclo", query = "SELECT g FROM Grupo g WHERE g.ciclo = :ciclo"),
    @NamedQuery(name = "Grupo.findByGrado", query = "SELECT g FROM Grupo g WHERE g.grado = :grado"),
    @NamedQuery(name = "Grupo.findByCLyGRD", query = "SELECT g FROM Grupo g WHERE g.ciclo=:ciclo AND g.grado = :grado"),
    @NamedQuery(name = "Grupo.countAll", query = "SELECT COUNT(g) FROM Grupo g"),
    @NamedQuery(name = "Grupo.countByCiclo", query = "SELECT COUNT(g) FROM Grupo g WHERE g.ciclo = :ciclo"),
    @NamedQuery(name = "Grupo.countByGrado", query = "SELECT COUNT(g) FROM Grupo g WHERE g.grado = :grado"),
    @NamedQuery(name = "Grupo.countByCLyGRD", query = "SELECT COUNT(g) FROM Grupo g WHERE g.ciclo=:ciclo AND g.grado = :grado")})
public class Grupo implements Serializable {
    @Column(name = "GRADO")
    private Integer grado;
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "IDG")
    private Integer idg;
    @Basic(optional = false)
    @Column(name = "GRUPO")
    private String grupo;    
    @OneToOne
    @JoinColumn(name = "CICLO_IDC", referencedColumnName = "IDC")
    private Ciclo ciclo;
    @ManyToMany
    @JoinTable(
      name="GRP_ALMN",
      joinColumns={@JoinColumn(name="GP_ID", referencedColumnName="IDG")},
      inverseJoinColumns={@JoinColumn(name="ALMN_ID", referencedColumnName="IDA")})
    private List<Alumno> alumnos;

    public void setAlumnos(List<Alumno> alumnos) {
        this.alumnos = alumnos;
    }

    public List<Alumno> getAlumnos() {
        return alumnos;
    }
    
    public void agregaAlumno(Alumno al){
        alumnos.add(al);
    }

    public Grupo() {
    }

    public Grupo(int idg) {
        this.idg = idg;
    }

    public Grupo(int idg, Ciclo ciclo, int grado, String grupo) {
        this.idg = idg;
        this.ciclo = ciclo;
        this.grado = grado;
        this.grupo = grupo;
    }

    public Integer getIdg() {
        return idg;
    }

    public void setIdg(int idg) {
        this.idg = idg;
    }

    public Ciclo getCiclo() {
        return ciclo;
    }

    public void setCiclo(Ciclo ciclo) {
        this.ciclo = ciclo;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idg != null ? idg.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Grupo)) {
            return false;
        }
        Grupo other = (Grupo) object;
        if ((this.idg == null && other.idg != null) || (this.idg != null && !this.idg.equals(other.idg))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return ciclo.toString()+" "+grado+grupo;
    }

    public Integer getGrado() {
        return grado;
    }

    public void setGrado(Integer grado) {
        this.grado = grado;
    }
    
}

/*
 * Alumno.java
 *   Entidad alumno
 * Parte de proyecto: Colegiaturas
 * Author: Pedro Cardoso Rodriguez
 * Mail: cardp_2004@yahoo.com.mx
 * Place: Zacatecas Mexico
 * 
    Copyright © 2013 Pedro Cardoso Rodriguez

    COLEGIATURAS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or any 
    later version.

    COLEGIATURAS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with COLEGIATURAS.  If not, see <http://www.gnu.org/licenses/>
 */
package colegiaturas.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Pedro
 */
@Entity
@Table(name = "ALUMNO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Alumno.findAll", query = "SELECT a FROM Alumno a"),
    @NamedQuery(name = "Alumno.countAll", query = "SELECT COUNT(a) FROM Alumno a"),
    @NamedQuery(name = "Alumno.findByIda", query = "SELECT a FROM Alumno a WHERE a.ida = :ida"),
    @NamedQuery(name = "Alumno.findByNombre", query = "SELECT a FROM Alumno a WHERE a.nombre = :nombre"),
    @NamedQuery(name = "Alumno.findByApp", query = "SELECT a FROM Alumno a WHERE a.app = :app"),
    @NamedQuery(name = "Alumno.findByApm", query = "SELECT a FROM Alumno a WHERE a.apm = :apm")})
public class Alumno implements Serializable {
    @Column(name = "BECA_PORCNT")
    private Integer becaPorcnt;
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "IDA")
    private Integer ida;
    @Basic(optional = false)
    @Column(name = "NOMBRE")
    private String nombre;
    @Basic(optional = false)
    @Column(name = "APP")
    private String app;
    @Basic(optional = false)
    @Column(name = "APM")
    private String apm;
    @Basic(optional = false)
    @Column(name = "PAPA_NOM")
    private String papaNom;
    @Column(name = "PAPA_APM")
    private String papaApm;
    @Basic(optional = false)
    @Column(name = "MAMA_NOM")
    private String mamaNom;
    @Basic(optional = false)
    @Column(name = "MAMA_ApM")
    private String mamaApm;
    @Column(name = "TELEFONO")
    private String telefono;
    @Column(name = "MOVIL")
    private String movil;
    @ManyToMany
    @JoinTable(
      name="GRP_ALMN",
      joinColumns={@JoinColumn(name="ALMN_ID", referencedColumnName="IDA")},
      inverseJoinColumns={@JoinColumn(name="GP_ID", referencedColumnName="IDG")})
    private List<Grupo> grupos;

    public List<Grupo> getGrupos() {
        return grupos;
    }

    public Alumno() {
    }

    public Alumno(Integer ida) {
        this.ida = ida;
    }

    public Alumno(Integer ida, String nombre, String app, String apm, int becaPorcnt, String papaNom, String mamaNom) {
        this.ida = ida;
        this.nombre = nombre;
        this.app = app;
        this.apm = apm;
        this.becaPorcnt = becaPorcnt;
        this.papaNom = papaNom;
        this.mamaNom = mamaNom;
    }

    public void setMamaApm(String mamaApm) {
        this.mamaApm = mamaApm;
    }

    public String getMamaApm() {
        return mamaApm;
    }

    public Integer getIda() {
        return ida;
    }

    public void setIda(Integer ida) {
        this.ida = ida;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public String getApm() {
        return apm;
    }

    public void setApm(String apm) {
        this.apm = apm;
    }

    public void setBecaPorcnt(int becaPorcnt) {
        this.becaPorcnt = becaPorcnt;
    }

    public String getPapaNom() {
        return papaNom;
    }

    public void setPapaNom(String papaNom) {
        this.papaNom = papaNom;
    }

    public String getPapaApm() {
        return papaApm;
    }

    public void setPapaApm(String papaApm) {
        this.papaApm = papaApm;
    }

    public String getMamaNom() {
        return mamaNom;
    }

    public void setMamaNom(String mamaNom) {
        this.mamaNom = mamaNom;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getMovil() {
        return movil;
    }

    public void setMovil(String movil) {
        this.movil = movil;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ida != null ? ida.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Alumno)) {
            return false;
        }
        Alumno other = (Alumno) object;
        if ((this.ida == null && other.ida != null) || (this.ida != null && !this.ida.equals(other.ida))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return getNombre()+" "+getApp()+" "+getApm();
    }

    public void setBecaPorcnt(Integer becaPorcnt) {
        this.becaPorcnt = becaPorcnt;
    }

    public Integer getBecaPorcnt() {
        return becaPorcnt;
    }
    
}
